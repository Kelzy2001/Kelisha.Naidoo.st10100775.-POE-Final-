
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author kelly
 */
public class Login {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login.LoginUser();
        Login.TaskMaker();
        
    }
        public static boolean checkUserName(){
        
        Matcher M;
        do{
    //This part runs the scanner for User Input
        System.out.println("Enter UserName");
        Scanner input = new Scanner(System.in);
        String User = input.nextLine();
    //This part checks to so whethere the pattern matches the compilers condition    
        Pattern P = Pattern.compile("((?=.*[_]).{5})");
        M = P.matcher(User);
        
    //The IF statement checks to see if the Input Matches the condition and gives the following statement   
        if(M.matches()){
            System.out.println("true");
           return true;
        }else{
            System.out.println("false");
        
        
        }   
    
        }while(!M.matches());
        return false;
    }
    
    public static boolean checkPasswordComplexity(){
    
        Matcher K;
        do{
    //This part runs the scanner for User Input
        System.out.println("Enter Password");
        Scanner input = new Scanner(System.in);
        String User = input.nextLine();
    //This part checks to so whethere the pattern matches the compilers condition    
        Pattern Pas = Pattern.compile("((?=.*[!@#$%^&*~])(?=.*[0-9])(?=.*[A-Z]).{8,20})");
        K = Pas.matcher(User);
        
        if(K.matches()){
            System.out.println("true");
            return true;
        }else{ 
            System.out.println("false");
         
        }
        }while(!K.matches());
        return false;
    }
    
    public static String registerUser(){
       
//[User Name Input and checker]

//This part runs the scanner for User Input
        Matcher M;
        do{
        System.out.println("Enter UserName");
        Scanner input = new Scanner(System.in);
        String User = input.nextLine();
    //This part checks to so whethere the pattern matches the compilers condition    
        Pattern P = Pattern.compile("((?=.*[_]).{5})");
        M = P.matcher(User);
        
    //The IF statement checks to see if the Input Matches the condition and gives the following statement   
        if(M.matches()){
        
           System.out.println("Username successfully captured");
           
        }else{
            
        System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
        }
        }while(!M.matches());
 //[Password Input and checker]       
      
//This part runs the scanner for User Input
        
        Matcher G;
        do{
        System.out.println("Enter Password");
        Scanner input4 = new Scanner(System.in);
        String User4 = input4.nextLine();
    //This part checks to so whethere the pattern matches the compilers condition    
        Pattern Pas = Pattern.compile("((?=.*[!@#$%^&*~])(?=.*[0-9])(?=.*[A-Z]).{8,20})");
        G = Pas.matcher(User4);
        
        if(G.matches()){
            System.out.println("Password successfully captured");
           
        }else{ 
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
         
        }
        }while(!G.matches());
    return registerUser();
    }
     
    
    
    public static boolean LoginUser(){
    
    // The information below is the User's Login details

    // UserName = â€œkyl_1â€
    // Password = Ch&&sec@ke99!

// The User's information are assigned two Strings

            String UserNameL = "kyl_1";
            String PasswordL = "Ch&&sec@ke99!";
 //This code runs a scanner to allow the user to Input their User Name and Password
            String UserName1;
            String Password1;
            do{
            System.out.println("Enter User Login");
            Scanner Input1 = new Scanner(System.in);
            UserName1 = Input1.nextLine();
            
            System.out.println("Enter Password");
            Scanner Input2 = new Scanner(System.in);
            Password1 = Input2.nextLine();
// This part of the code checks to see if the conditions for the Login have been met and outputs the correct response

           if(UserName1.equals(UserNameL) && Password1.equals(PasswordL)){
               
               System.out.println("true");
               JOptionPane.showMessageDialog(null, "â€œWelcome to EasyKanbanâ€ ");
               TaskApp();
           return true;
           }
           else{
               System.out.println("false");
           
           }
            }while(!UserName1.equals(UserNameL) && !Password1.equals(PasswordL));
            return false;
           
           
    }
    
    
    public static String returnLoginStatus(){
        
         // The information below is the User's Login details

    // UserName = â€œkyl_1â€
    // Password = Ch&&sec@ke99!

// The User's information are assigned two Strings
            
            String UserName1;
            String Password1;
            do{
            String UserNameL = "kyl_1";
            String PasswordL = "Ch&&sec@ke99!";
 //This code runs a scanner to allow the user to Input their User Name and Password           
            System.out.println("Enter User Login");
            Scanner Input1 = new Scanner(System.in);
            UserName1 = Input1.nextLine();
            
            System.out.println("Enter Password");
            Scanner Input2 = new Scanner(System.in);
            Password1 = Input2.nextLine();
        
        // This part of the code checks to see if the conditions for the Login have been met and outputs the correct response

           if(UserName1.equals("kyl_l") && PasswordL.equals("Ch&&sec@ke99!")){
               
              System.out.println("Welcome <user first name> ,<user last name> it is great to see you again. ");   
          }
           else{
              System.out.println("Username or password incorrect, please try again");
           }

            }while(!UserName1.equals("kyl_l") && !Password1.equals("Ch&&sec@ke99!"));
        
    return returnLoginStatus();
    }
    
    
    
    public static boolean TaskApp(){
        
        int Val;
       do{  
   String [] Options = {"Add Task","Show Report(Coming Soon)","Cancel"};
        
       Val = JOptionPane.showOptionDialog(
                null, //ignore
                "Please Select an Option", //Message Text
                "Task Option", //Title
                JOptionPane.YES_NO_CANCEL_OPTION, //Allows us the 3 button option
                JOptionPane.PLAIN_MESSAGE, //OptionPane
                null, //ignore
                Options, //Array
                0);
// System.out.println(Val);
        
       
        
        if(Val == 0){
        
        
        TaskNum();
        break;
        
        }
        if(Val == 2){
        //This closes the app
        break;
       
        }
        //this loops the program if Show Report(coming soon) was chosen
       }while(Val ==1);

return true;
}
    
  public static boolean TaskNum(){
// The following code runs an Input Pane and then a method depending on the number of inputs

                String Number = JOptionPane.showInputDialog("Input Number Of Tasks:");
                int a = Integer.parseInt(Number);
                
                for(int i = 0; i < a; i++){
                
                TaskMaker();
                
                
                }
        
    return true;
    }   
    
    
   public static boolean TaskMaker(){
    //Allows you to add te Task Name and Number
       String TName = JOptionPane.showInputDialog("Task Name");
        
       String TNum = JOptionPane.showInputDialog("Task Number");
   
    // This allows you to add a task description with a 50 character word limit
    
        String Desc = JOptionPane.showInputDialog("Task Description:");
        Pattern P = Pattern.compile("((?=.*[a-z]).{0,50})");
        Matcher M = P.matcher(Desc);
        if(M.matches()){
            JOptionPane.showMessageDialog(null, "â€œTask successfully capturedâ€ ");
        
        }else {
        
            JOptionPane.showMessageDialog(null,"â€œPlease enter a task description of less than 50 charactersâ€ ");
        
        }
 // This allows you to add the Developer Details (First Name + Last Name) and the task Duration in hours
 
       String DDet = JOptionPane.showInputDialog("Developer Details:");
       
       String Dur = JOptionPane.showInputDialog("Task Duration (in Hours)");
       
       
//This code generates a unique ID using the first letters of the Task Name, the Task Number and last three letters of the Developer name 
                  
        String Last3 = DDet.substring(DDet.length() - 3);
        String Tn = TName.substring(0,2);
        JOptionPane.showMessageDialog(null,"Task ID - " + (Tn + ":" + TNum + ":" + Last3).toUpperCase());
      
// This code shows a three option message box that allows the user to select the state of the task

        String[] Status ={"To Do","Doing","Done"};
        int State = JOptionPane.showOptionDialog(null, 
                "Task Status", 
                "Task Status",  
                JOptionPane.YES_NO_CANCEL_OPTION, 
                JOptionPane.INFORMATION_MESSAGE, 
                null, 
                Status,
                Status[0]);
        
        
//This Code outputs a message box with all the task details
        JOptionPane.showMessageDialog(null,
                "Task Status: " + Status[State] + "\n" + 
                " Developer Details: " + DDet + "\n" + 
                "Task Number : " + TNum + "\n" + 
                "Task Name : " + TName + "\n" + 
                "Task Description :" + Desc + "\n" + 
                "Task ID - " + (Tn + ":" + TNum + ":" + Last3).toUpperCase() +"\n" +
                "Duration : " + Dur + "hrs"                              
                        );
         
        
           ArrayList<String> List = new ArrayList<String>();

            List.add("Developer Name : " + DDet);
            List.add("Task Name :" + TName);
            List.add("Task ID : " + (Tn + ":" + TNum + ":" + Last3).toUpperCase() );
            List.add("Task Duration : " + Dur + "hr(s)");
            List.add("Task Status : " + Status[State]);
        
        //For User Population
        

        
        String[] Popper = List.toArray(new String[0]);
        JOptionPane.showMessageDialog(null, Arrays.toString(Popper));
        ////////////////////
        
        
        
    //This line of code runs the ArrayList application for user storage and manipulation    
        ArrayApp();
    return true;
    }  
   public static boolean ArrayApp() {
   
       
    //The following code ask the user if they would like to see their Task List and gives the user various options is yes is selected       
        int ListOp;
        do{
             ListOp = JOptionPane.showOptionDialog(null,
                        "List Option", 
                        "Do you want to see your task list?", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.PLAIN_MESSAGE, 
                        null, 
                        null, 
                        0);
        
       //Runs the following code if yes is selected 
        if(ListOp == 0){
            
            String[] TaskOp = {
                "Display Completed Task(s)",
                "Longest Task(s)",
                " Search Task",
                "Search by Developer",
                "Delete Task",
                "Report of All Tasks",
                "Cancel"};
            
           int TOP = JOptionPane.showOptionDialog(null,
                        "Task List Option", 
                        "Please Select Option", 
                        JOptionPane.YES_NO_CANCEL_OPTION, 
                        JOptionPane.PLAIN_MESSAGE, 
                        null, 
                        TaskOp, 
                        0);
        
           
           
        String[] Person1 = {"Mike Smith","Create Login","5","To Do"};
        
        String[] Person2 = {"Edward Harrison","Create Add Features","8","Doing"}; 
            
        String[] Person3 = {"Samantha Paulson","Create Reports","2","Done"}; 
        
        String[] Person4 = {"Glenda Oberholzer","Add Arrays","11","To Do"}; 
        
      
            //This line of code displays all the users whos projects are done
            if(TOP == 0 ){ ///A
                
                if(Arrays.asList(Person3).contains("Done")){
                
                    for(String c : Person3){
                        
                        Arrays.toString(Person3);
                        JOptionPane.showMessageDialog(null, Person3);
                        break;
                        //System.out.println(c);
                    }
                
                }
                
                
                
            }
            //This line of code displays the task and developer with the longest Task duration
            if(TOP == 1){ ///B
                
                if(Arrays.asList(Person4).contains("11")){
                    
                    JOptionPane.showMessageDialog(null, Person4[0].toString() +":" + " " + Person4[2].toString() +"hrs" );
                                         
                   
                    
                }
                
            }
            //The Following code allows the user to search for the Task using the Task Name
            if(TOP == 2){ ///C
             
                    String Looker = JOptionPane.showInputDialog("Please Enter Task Name : ");
            //The Arrays are converted to ArrayLists and are then compared to the JOptionPane to see if their values match        
                    if(Arrays.asList(Person1).contains(Looker)){

                                     for(String i : Person1){
                                         Arrays.toString(Person1);
                                           JOptionPane.showMessageDialog(null, Person1);
                                            break;
                                        // System.out.println(i);
                                     }
                    }                 
                     if(Arrays.asList(Person2).contains(Looker)){

                                     for(String i : Person2){
                                         
                                         Arrays.toString(Person2);
                                        JOptionPane.showMessageDialog(null, Person2);
                                        break;
// System.out.println(i);
                                     }
                     }                 
                     if(Arrays.asList(Person3).contains(Looker)){

                                     for(String i : Person3){
                                         
                                         Arrays.toString(Person3);
                                        JOptionPane.showMessageDialog(null, Person3);
                                        break;
                                         //System.out.println(i);
                                     }
                     }                 
                     if(Arrays.asList(Person4).contains(Looker)){

                                     for(String i : Person4){
                                         
                                         Arrays.toString(Person4);
                                        JOptionPane.showMessageDialog(null, Person4);
                                        break;

// System.out.println(i);
                                     } 
                     }                
                              
            
            }
            //The following code allows the user to find all the tasks assigned to a Developer
            if(TOP == 3){
                
                String Dev = JOptionPane.showInputDialog("Please Enter Developer Name :");
                
                if(Arrays.asList(Person1).contains(Dev)){
                
                    for(String j : Person1){
                        
                        Arrays.toString(Person1);
                        JOptionPane.showMessageDialog(null, Person1);
                        break;
                        //System.out.println(j);
                    }      
                }
                
                if(Arrays.asList(Person2).contains(Dev)){
                
                    for(String j : Person2){
                    
                        Arrays.toString(Person2);
                        JOptionPane.showMessageDialog(null, Person2);
                        break;
                        //System.out.println(j);
                    }      
                }
                
                if(Arrays.asList(Person3).contains(Dev)){
                
                    for(String j : Person3){
                        
                        Arrays.toString(Person3);
                        JOptionPane.showMessageDialog(null, Person3);
                        break;
                        //System.out.println(j);
                    }      
                }
                
                if(Arrays.asList(Person4).contains(Dev)){
                
                    for(String j : Person4){
                        
                        Arrays.toString(Person4);
                        JOptionPane.showMessageDialog(null, Person4);
                        break;
                    
// System.out.println(j);
                    }      
                }
            
            }
            //The following code allows the user to delete a named task
            if(TOP == 4){
            
                String TND = JOptionPane.showInputDialog("Please Enter Task Name : ");
                
                    if(Arrays.asList(Person1).contains(TND)){
                                
                                Person1[0] = null;
                                Person1[1] = null;
                                Person1[2] = null;
                                Person1[3] = null;
                                JOptionPane.showMessageDialog(null,"Task Has Been Deleted");
                                for(String d : Person1){

                                    Arrays.toString(Person1);
                                    JOptionPane.showMessageDialog(null, Person1);
                                    break;
                                    //System.out.println(d);

                                }
                    }
                    if(Arrays.asList(Person2).contains(TND)){

                                Person2[0] = null;
                                Person2[1] = null;
                                Person2[2] = null;
                                Person2[3] = null;
                             JOptionPane.showMessageDialog(null,"Task Has Been Deleted");
                                for(String d : Person2){

                                   Arrays.toString(Person2);
                                    JOptionPane.showMessageDialog(null, Person2);
                                    break;
                                    //System.out.println(d);

                                }
                    }
                    if(Arrays.asList(Person1).contains(TND)){

                                Person3[0] = null;
                                Person3[1] = null;
                                Person3[2] = null;
                                Person3[3] = null;
                             JOptionPane.showMessageDialog(null,"Task Has Been Deleted");
                                for(String d : Person3){
                                    
                                    Arrays.toString(Person3);
                                    JOptionPane.showMessageDialog(null, Person3);
                                    break;
                                   
                                    //System.out.println(d);

                                }
                    }
                    if(Arrays.asList(Person4).contains(TND)){

                                Person4[0] = null;
                                Person4[1] = null;
                                Person4[2] = null;
                                Person4[3] = null;
                            JOptionPane.showMessageDialog(null,"Task Has Been Deleted");
                                for(String d : Person4){

                                   Arrays.toString(Person4);
                                    JOptionPane.showMessageDialog(null, Person4);
                                    break;
                                    //System.out.println(d);

                                }
                    }
            
            }
            //The following code displays a full report all of the tasks
            if(TOP == 5){
            
               for(String i : Person1){
                   
                                    Arrays.toString(Person1);
                                    JOptionPane.showMessageDialog(null, Person1);
                                    break;
                  //System.out.println(i);   
                }  
// System.out.println(" ");
               for(String i : Person2){
                   
                                    Arrays.toString(Person2);
                                    JOptionPane.showMessageDialog(null, Person2);
                                    break;
                  //System.out.println(i);   
                }  
// System.out.println(" ");
               for(String i : Person3){
                   
                                    Arrays.toString(Person3);
                                    JOptionPane.showMessageDialog(null, Person3);
                                    break;
                  //System.out.println(i);   
                }  
// System.out.println(" ");
               for(String i : Person4){
                   
                                    Arrays.toString(Person4);
                                    JOptionPane.showMessageDialog(null, Person4);
                                    break;
                  //System.out.println(i);   
                }  
                
            }
            
            
            //The following code ends the application
            if(TOP == 6){
            JOptionPane.showMessageDialog(null, "Have a Nice Day!");
            break;
            }
            
           
        }  
        }while(ListOp != 1);
   
   
   
   return true;
   }
    
}
